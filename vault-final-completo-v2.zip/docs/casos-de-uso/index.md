# Casos de Uso

## Atores
- Usuário
- Visitante
- Administrador

## Diagrama de Casos de Uso
```mermaid
flowchart TD
    Usuario --> Buscar
    Usuario --> Download
    Usuario --> Biblioteca
    Usuario --> Executar
```

## Casos
- Buscar jogos
- Download
- Gerenciar biblioteca
- Executar jogos

## Fluxo
```mermaid
flowchart TD
    A --> B --> C --> D
```
